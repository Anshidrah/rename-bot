# - File Rename Bot

<p align="center">
  <a href="https://github.com/No-OnE-Kn0wS-Me/FileRenameBot/stargazers">
    <img src="https://img.shields.io/github/stars/No-OnE-Kn0wS-Me/FileRenameBot?style=social">

  </a>
  
  <a href="https://github.com/No-OnE-Kn0wS-Me/FileRenameBot/fork">
    <img src="https://img.shields.io/github/forks/No-OnE-Kn0wS-Me/FileRenameBot?label=Fork&style=social">

  </a>  
</p>

->**An Multi purpose Bot Which Can :-**
* ✅Rename Telegram Files Into Any Formats <pre>(Like Renaming Video Files Into Audio File Or Images Into Stickers, Can Be Rename Any File To Most Of The Available Extensions 🤔 I gus) </pre>
* ✅Convert Files into Video
* ✅Supports Custom Caption/ Permanent Thumbnail
* ✅Force Subscribe To Targeted Chat

->**Demo Bots**

➡️[BOT 1](https://t.me/rename1robot)    
➡️[BOT 2](https://t.me/rename2robot)    
➡️[BOT 3](https://t.me/rename3robot)    
➡️[BOT 4](https://t.me/rename4robot)   
➡️[BOT 5](https://t.me/rename5robot)


# Deploy straight to Heroku!

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/No-OnE-Kn0wS-Me/FileRenameBot)

# Required Strings :-

* -> `TG_BOT_TOKEN`<br> **Your Bot Token Taken From [@BotFather](https://t.me/botfather)**

* -> `UPDATE_CHANNEL`<br> **An Channel Username Which You Want to Use As An ForceSub Channel Put It Without @**

* -> `APP_ID`__And__ `API_HASH`<br>**Get It From [Here](http://www.my.telegram.org) or [@UseTGXBot](http://www.telegram.dog/UseTGXBot)**

## Credits, and Thanks to Beloved Developers ;

* [SpEcHlDe](https://telegram.dog/SpEcHlDe) For [AnydlBot](https://github.com/SpEcHiDe/AnyDLBot)
* [Dan](https://github.com/delivrance) For This Mind Blowing [Library](https://github.com/pyrogram/pyrogram)
